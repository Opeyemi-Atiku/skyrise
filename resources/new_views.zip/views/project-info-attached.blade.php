<!DOCTYPE html>
<html lang="en">

<head>
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
		<![endif]-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>Client-Project-Info</title>
	<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/assets/css/easy-responsive-tabs.css">
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
	<link href="/assets/images/fav-icon.png" rel="icon">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
	<link href="/assets/style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="/assets/css/pushy.css">
	<link rel="stylesheet" href="/assets/sidenav.min.css">
	<link rel="stylesheet" href="/assets/css/sidenav.min.css">
	<link rel="stylesheet" href="/assets/css/lightboxed.css">
	<style>
		a.carousel-control-prev,
		a.carousel-control-next {
			width: 50px;
			height: 50px;
			top: 45%;
			background: #007efa;
		}
	</style>
</head>

<body>
	<div class="overlay">
		<div class="overlay__inner">
			<div class="overlay__content"><span class="spinner"></span></div>
		</div>
	</div>

	@include('navbar')

	<section class="main-banner">
		<img src="https://skyriseprojects.com/testapi/public/uploads/images/{{ $project->images[0] }}" class="w-100">
	</section>
    
	<div id="sticky-anchor"></div>
	<div id="sticky" class="grey-bg clearfix">

		<div class="container">
			<h1>{{ $project->name }}</h1>
		</div>
	</div>
	@if($project->promotions)
    	<div class="sale-alrt">
    		<div class="container">
    			<h2>
    				SALES PROMOTION
    			</h2>
    			<p>
    				{{ $project->promotions[0]['desc'] }} <a href="/contact">Contact Us</a>
    			</p>
    		</div>
    	</div>
    @endif
	<div class="inner-content">
		<div class="container">

			<h4 class="main-page-h">DETAILS</h4>
			<p class="b-44">
	            {{ $project->description }}
			</p>
			<div class="info-area">
				<div class="row">
					<div class="col-md-6">
						<ul class="data-desc">
							<li>
								<span>Address</span>
								{{ $project->address }}

							</li>
						</ul>
						<ul class="data-desc">
							<li>
								<span>Property type</span>
								{{ $project->condos != null? $project->condos. 'Condos ' : '' }} <i></i> {{ $project->townhouse != null? $project->townhouse. 'Townhouse ' : ''  }} <i></i> {{ $project->rowhouse != null ? $project->rowhouse. 'Rowhouse' : '' }}
							</li>
						</ul>
						<ul class="data-desc">
							<li>
								<span>Base Price (CAD)</span>
								From ${{ $project->price }}
							</li>
						</ul>
						@if($project->levels != '')
						<ul class="data-desc">
							<li>
								<span>Levels</span>
								{{ $project->levels }}
							</li>
						</ul>
						@endif
						<ul class="data-desc">
							<li>
								<span>Developer</span>
								{{ $project->developer->name }}
							</li>
						</ul>
						@if($project->architect != '')
						<ul class="data-desc">
							<li>
								<span>Architect</span>
								{{ $project->architect }}
							</li>
						</ul>
						@endif
						<div class="clearfix"></div>
						@if($project->designer != '')
						<ul class="data-desc">
							<li class="mb-0">
								<span>Interior Designer</span>
								{{ $project->designer }}
							</li>
						</ul>
						@endif
					</div>
					<div class="col-md-6">
						<ul class="data-desc mt-30">
							<li class="pl-md-1">
								<span>Sales centre</span>
								8157 Willingdon Avenue <a href="">(Map)</a><br>
								Burnaby, BC<br>
								Canada
							</li>
							@if($project->sales_company != '')
							<li class="pl-md-1">
								<span>Sales company / Brokerage / Agent</span>
								{{ $project->sales_company }}
							</li>
							@endif
							@if($project->completion_mnth != '' && $project->completion_year != '')
							<li class="pl-md-1">
								<span>Completion date (estimate)</span>
								{{ $project->completion_mnth }} {{ $project->completion_year }}
							</li>
							@endif
							@if($project->status != '')
							<li class="pl-md-1 mb-0">
								<span>Status</span>
								{{ $project->status }}
							</li>
							@endif
						</ul>
					</div>
				</div>
			</div>
		</div>

		<div class="deposit-bg">

			<div class="container">
				<h2>
					DEPOSIT TERMS
				</h2>
				<p>
				    {{ $project->deposit_terms }}
				</p>
			</div>
		</div>

		<div class="photo-slider">
			<div class="container">
				<h2 class="new-values">PHOTOS</h2>
			</div>
			<div id="slider1" class="slider">
				<div class="stage">
					<div class="inside">
						<div class="stager photo-list">
						    @foreach($project->images as $image)
    							<div class="item">
                                    <img class="lightboxed w-100" rel="group1" src="https://skyriseprojects.com/testapi/public/uploads/images/{{ $image }}" data-link="https://skyriseprojects.com/testapi/public/uploads/images/{{ $image }}" alt="Image Alt"  />
                                </div>
                            @endforeach
							
						</div>
					</div>
				</div>
				<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
				<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
			</div>

		</div>
<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
      
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    <iframe width="560" height="315" src="" id="videoFrame" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
 
    </div>
  </div>
</div>


		<div class="video-slider">
			<div class="container">
				<h2 class="new-values">VIDEOS</h2>
			</div>
			<div id="slider2" class="slider">
				<div class="stage">
					<div class="inside">
						<div class="stager video-list">
						    @foreach($project->videos as $video)
    							<div class="item">
                                    <img class="w-100" data-toggle="modal" onClick="$('#videoFrame').attr('src', 'https://www.youtube.com/embed/{{ $video['id'] }}')" data-target="#exampleModalCenter" src="https://img.youtube.com/vi/{{ $video['id'] }}/mqdefault.jpg" data-link="https://img.youtube.com/vi/{{ $video['id'] }}/mqdefault.jpg" />
    	                            <span>{{ $video['title'] }}</span>
    							</div>
							@endforeach
						
						</div>
					</div>
				</div>
				<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
				<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
			</div>

		</div>
		<div class="container">
			<!-- btn row end -->
			@if($project->deposit_terms != '')
			<h2 class="page-heading">
				DEPOSIT TERMS
			</h2>
			<p>{{ $project->deposit_terms }}</p>
			@endif


			<h2 class="page-heading">
				AMENITIES
			</h2>
			<div class="row">
				@foreach($project->amenities as $ammenity)
				<div class="col-md-6">
					<div class="am-cvr">
						<span>{{ $ammenity['title'] }}</span>
						<p>{{ $ammenity['desc'] }}</p>

					</div>
				</div>
				@endforeach
			</div>
		</div>

        @for($i = 0; $i < count($project->floors); $i++)
    		<div class="video-slider {{ $i % 2 > 0? '' : 'bg-white' }}">
    			<div class="container">
    				<h2 class="new-values mb-30">{{ $project->floors[$i]['name'] }}</h2>
    			</div>
    			<div id="slider3" class="slider">
    				<div class="stage">
    					<div class="inside">
    						<div class="stager photo-list">
    							@foreach($project->floors[$i]['section'] as $key => $section)
    							    <div class="item">
    
        								<a href="#" data-toggle="modal" data-target="#exampleModalCenter2">
        									<div class="border-img">
        									   
        										<img src="https://skyriseprojects.com/testapi/public/uploads/floor_media/{{ $section['images']['url'] }}" class="popData" alt="" bed="{{ $section['bedrooms'] }}" bath="{{ $section['bathrooms'] }}" den="{{ $section['den'] }}" name="{{ $section['plan'] }}" int="{{ $section['sf_int'] }}" ext="{{ $section['sf_ext'] }}" area="{{ $section['sf_int'] + $section['sf_ext'] }}" basePrice="{{ array_key_exists('unit_price1', $section) ? '$'.$section['unit_price1'] : '----' }}" pricePer="----" level="----" unitsRem="{{ $section['units'] }}" image="{{ $section['images']['url'] }}" sheet="{{ array_key_exists('url', $section['sheet']) ? $section['sheet']['url'] : '' }}" doc="{{ $project->documents != null ? $project->documents[0]['url'] : '' }}" />
        
        									</div>
        								</a>
        								<div class="g-bg clearfix">
        									<div class="row">
        										<div class="col-9">
        											<b>PLAN {{ $key + 1 }}</b>
        										</div>
        										<div class="col-3">
        											<div class="hrt-cvr"><a href="javascript:void();" class="star-yellow c-y"><i class="zmdi zmdi-star"></i></a></div>
        										</div>
        									</div>
        								</div>
        								<ul class="specs clearfix">
        									<li>Bedrooms:{{ $section['bedrooms'] }}</li>
        									<li>Bath:{{ $section['bathrooms'] }}</li>
        									<li>Den:{{ $section['den'] }}</li>
        								</ul>
        								<ul class="specs clearfix">
        									<li>Interior: {{ $section['sf_int'] }} SF</li>
        									<li>Exterior: {{ $section['sf_ext'] }} SF</li>
        									<li>Total: {{ $section['sf_int'] + $section['sf_ext'] }} SF</li>
        								</ul>
        								<ul class="specs clearfix">
        									<li>{{ array_key_exists('unit_price1', $section) ? '$'.$section['unit_price1'] : '----'}}</li>
        									
        								</ul>
        
        							</div>
                                @endforeach
    						 
                                
    
    						</div>
    					</div>
    				</div>
    				<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
    				<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
    			</div>
    
    		</div>
        @endfor
        
		
	</div>
	</div>
	</div>
	<br>
	<br>
	<br>
	<br>
	<br>
	<!--Video Modal -->
	<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-dialog-centered bg-blk" role="document">
			<div class="modal-content bg-blk">

				<div class="modal-body bg-blk">
					<button type="button" class="close bg-black" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<iframe width="100%" height="300px" src="" id="videoIframe" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</div>

			</div>
		</div>
	</div>

	<div class="modal fade bd-example-modal-lg" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
		<div class="modal-dialog modal-fullscreen  modal-dialog-centered" role="document">
			<div class="modal-content">


				<button type="button" class="close ex-t-new" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>

				<div class="modal-body">
					<div class="row">
						<div class="col-md-12 col-lg-6">
							<img src="https://annoying.skyriseprojects.com/assets/images/plann-1.jpg" alt="" class="w-100" id="popImage" style="height: 100%;" />
						</div>
						<div class="col-md-12 col-lg-6">
							<div class="conte-sec">
								<h3 id="popName"></h3>
								<!--<span id="popType">1 BEDROOM + 1 BATHROOM</span>-->
								<ul class="total-cst clearfix">
                                    <li>Bedrooms</li>
                                    <li id="popBed"></li>
                                    <li>Bathrooms</li>
                                    <li><span id="popBath"></span></li>
                                    <li>Dens</li>
                                    <li><span id="popDen"></span></li>
                                    
                                    <li>INTERIOR</li>
                                    <li id="popInt"></li>
                                    <li>EXTERIOR</li>
                                    <li><span class="btm-bd" id="popExt"></span></li>
                                    <li>TOTAL AREA</li>
                                    <li id="popArea"></li>
                                    
                                    <li>Base price(CAD)</li>
                                    <li id="popBaseP"></li>
                                    <li>Price / SF</li>
                                    <li><span id="popPricePer"></span></li>
                                    
                                    <li>Level</li>
                                    <li id="popLevel"></li>
                                    <li>Units remaining</li>
                                    <li><span id="popUnitsRem"></span></li>
                                </ul>
								<div class="row">
									<div class="col-6 pr-1">
										<a download id="popFloor" href="#" class="pt-btn"><i class="zmdi zmdi-download"></i> FLOOR PLAN</a>
									</div>
									<div class="col-6 pl-1">
										@if($project->documents != null)<a download href="{{ $project->documents[0]['url'] }}" class="pt-btn"><i class="zmdi zmdi-download"></i> FEATURE SHEET</a>@endif
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
				<!--<div class="modal-footer">
	  <div class="row">
	  <div class="col-6">
   <a href="" class="prev-bt"><i class="zmdi zmdi-chevron-left"></i> Previous plan</a
	   </div>
	    <div class="col-6">
	    <div class="text-right">
     <a href="" class="next-bt">Next plan <i class="zmdi zmdi-chevron-right"></i></a
	     </div>
	     </div>
      </div>
    </div>-->
			</div>
		</div>
	</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script type="text/javascript" src="https://annoying.skyriseprojects.com/assets/js/slideshow.min.js"></script>
	<script src="/assets/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
	<script>
		var swiper = new Swiper('.swiper-two', {
			slidesPerView: 1.14,
			spaceBetween: 15,

			speed: 300,
			freeMode: false,
			slidesPerGroup: 1,
			loop: false,
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			},
			breakpoints: {

				767: {
					slidesPerView: 3,
					slidesPerGroup: 3,
					spaceBetween: 30,
					speed: 1200

				}

			}
		});
	</script>
	<script type="text/javascript" src="/assets/js/dropdown.js"></script>
	<script type="text/javascript" src="/assets/sidenav.min.js"></script>
	<script type="text/javascript" src="/assets/js/lightboxed.js"></script>
	<script>
		$('[data-sidenav]').sidenav();
	</script>
	<script>
		$('.popData').click(function() {
    popBed,popBath,popDen,popInt,popExt,popArea,popBaseP,popPricePer,popLevel,popUnitsRem
			var image = $(this).attr('image');
			var sheet = $(this).attr('sheet');
			var doc = $(this).attr('doc');
			var name = 'Plan '+$(this).attr('name');
			var bed = $(this).attr('bed');
			var bath = $(this).attr('bath');
			var den = $(this).attr('den');
			var int = $(this).attr('int')+' SF';
			var ext = $(this).attr('ext')+' SF';
			var basePrice = $(this).attr('basePrice');
			var pricePer = $(this).attr('pricePer');
			var level = $(this).attr('level');
			var unitsRem = $(this).attr('unitsRem');
			var area = $(this).attr('area')+' SF';


			$('#popImage').attr('src', 'https://skyriseprojects.com/testapi/public/uploads/floor_media/' + image);
			$('#popFloor').attr('href', 'https://skyriseprojects.com/testapi/public/uploads/floor_sheet/' + sheet);
// 			$('#popType').text(bed + ' Bedrooms + ' + bath + ' Bathrooms');
			$('#popName').text(name);
			$('#popBed').text(bed);
			$('#popBath').text(bath);
			$('#popDen').text(den);
			$('#popBaseP').text(basePrice);
			$('#popPricePer').text("----");
			$('#popLevel').text("----");
			$('#popUnitsRem').text(unitsRem);
			$('#popInt').text(int);
			$('#popExt').text(ext);
			$('#popArea').text(area);

		});
	</script>
	<script>
		$('.panel-collapse').on('show.bs.collapse', function() {
			$(this).siblings('.panel-heading').addClass('active');
		});

		$('.panel-collapse').on('hide.bs.collapse', function() {
			$(this).siblings('.panel-heading').removeClass('active');
		});
	</script>
	<script src="/assets/js/pushy.min.js"></script>
	<script>
		$('#slct22').change(function() {
			alert('aYYZA');
			$('li.pushy-submenu').removeClass('pushy-submenu-closed');
			$('li.pushy-submenu').addClass('pushy-submenu-open');
		});
	</script>


	<script>
		$('.dropdown-el').click(function(e) {
			e.preventDefault();
			e.stopPropagation();
			$(this).toggleClass('expanded');
			$('#' + $(e.target).attr('for')).prop('checked', true);
		});
		$(document).click(function() {
			$('.dropdown-el').removeClass('expanded');
		});
	</script>
	<script>
		$(window).on('load', function() {

			$('body').removeClass('stop-scrolling');
		});
	</script>
	<script>
		$(window).on('load', function() {
			$('.overlay').fadeOut(500);
		})
	</script>
	<script>
		function sticky_relocate() {
			var window_top = $(window).scrollTop();
			var div_top = $('#sticky-anchor').offset().top;
			if (window_top > div_top) {
				$('#sticky').addClass('stick');
			} else {
				$('#sticky').removeClass('stick');
			}
		}

		$(function() {
			$(window).scroll(sticky_relocate);
			sticky_relocate();
		});
	</script>
	<script>
		$(document).ready(function() {
			$(".forgot").click(function() {
				$(".login-form").hide(500);
				$(".forgot-form").show(500);
			});
		});
	</script>

</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
		<![endif]-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>Home</title>
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/images/fav-icon.png" rel="icon">
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
	<link href="assets/style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="assets/css/fullpage.css" />
	<link rel="stylesheet" href="assets/css/pushy.css">
	<link rel="stylesheet" href="/assets/sidenav.min.css">

</head>

<body>
	<div class="overlay">
		<div class="overlay__inner">
			<div class="overlay__content"><span class="spinner"></span></div>
		</div>
	</div>

	@include('navbar')
	<section class="main-banner">
		<div class="container">
			<div class="caption-max">
				<h1>
					Selling real estate presale and
					new home construction projects.</h1>

				<div class="row">
					<div class="col-4">
						<div class="align">
							<div class="stat-wrap">
								<div class="counter">

									<span class="stat-number">{{ $developers }}</span>
									<h3>Real estate developers</h3>
								</div>

							</div>
						</div>
					</div>
					<div class="col-4">
						<div class="stat-wrap">
							<div class="counter">

								<span class="stat-number">{{ $projects }}</span>
								<h3>Real estate projects</h3>
							</div>

						</div>
					</div>
					<div class="col-4">
						<div class="stat-wrap">
							<div class="counter">

								<span class="stat-number">{{ $presale_count }}</span>
								<h3>Total presale units</h3>
							</div>

						</div>
					</div>
				</div>

				<a href="" class="primary-btn small auto-marg">Sign up, it’s free!</a>
			</div>
		</div>
	</section>
    
    
    
    
    @if($condoCount > 0)
        <section class="featured-condo">
		<div class="featured-outer">
			<div class="container">
				<h2>Featured condo projects</h2>
			</div>
			<div id="slider1" class="slider">
				<div class="stage">
					<div class="inside">
						<div class="stager">
							
							@foreach($all_projects as $proj)
							    @if($proj->condos !== null)
    							    <div class="item">
        								<div class="condo-outer">
        
        									<div class="condo-bx clearfix">
        										<a href="/project-info/{{ $proj->type_id }}/{{ $proj->id }}">
        											<img src="https://skyriseprojects.com/testapi/public/uploads/images/{{ $proj->images[0] }}" alt="" />
        											<div class="box-desc">
        												<h3>{{ $proj->name }}</h3>
    												    <h4>{{ $proj->city }}</h4>
        											</div>
        										</a>
        										<div class="box-fav"><i class="zmdi zmdi-favorite"></i></div>
        									</div>
        								</div>
        							</div>
        						@endif
							@endforeach
						</div>
					</div>
				</div>
				<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
				<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
			</div>
		</div>
	</section>
    @endif
    
    @if($townCount > 0)
	    <section class="featured-condo bg-white">
    		<div class="featured-outer">
    			<div class="container">
    				<h2>Featured townhouse projects</h2>
    			</div>
    			<div id="slider2" class="slider">
    				<div class="stage">
    					<div class="inside">
    						<div class="stager">
    							@foreach($all_projects as $proj)
    							    @if($proj->townhouse !== null)
        							    <div class="item">
            								<div class="condo-outer">
            
            									<div class="condo-bx clearfix">
            										<a href="/project-info/{{ $proj->type_id }}/{{ $proj->id }}">
            											<img src="https://skyriseprojects.com/testapi/public/uploads/images/{{ $proj->images[0] }}" alt="" />
            											<div class="box-desc">
            												<h3>{{ $proj->name }}</h3>
        												    <h4>{{ $proj->city }}</h4>
            											</div>
            										</a>
            										<div class="box-fav"><i class="zmdi zmdi-favorite"></i></div>
            									</div>
            								</div>
            							</div>
            						@endif
    							@endforeach
    						</div>
    					</div>
    				</div>
    				<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
    				<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
    			</div>
    		</div>
    	</section>
    @endif
    
    @if($rowCount > 0)
	    <section class="featured-condo">
    		<div class="featured-outer">
    			<div class="container">
    				<h2>Featured row house projects</h2>
    			</div>
    			<div id="slider1" class="slider">
    				<div class="stage">
    					<div class="inside">
    						<div class="stager">
    							@foreach($all_projects as $proj)
    							    @if($proj->rowhouse !== null)
        							    <div class="item">
            								<div class="condo-outer">
            
            									<div class="condo-bx clearfix">
            										<a href="/project-info/{{ $proj->type_id }}/{{ $proj->id }}">
            											<img src="https://skyriseprojects.com/testapi/public/uploads/images/{{ $proj->images[0] }}" alt="" />
            											<div class="box-desc">
            												<h3>{{ $proj->name }}</h3>
        												    <h4>{{ $proj->city }}</h4>
            											</div>
            										</a>
            										<div class="box-fav"><i class="zmdi zmdi-favorite"></i></div>
            									</div>
            								</div>
            							</div>
            						@endif
    							@endforeach
    						</div>
    					</div>
    				</div>
    				<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
    				<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
    			</div>
    		</div>
    	</section>
    @endif
    
    @if($duplexCount > 0)
	    <section class="featured-condo bg-white">
    		<div class="featured-outer">
    			<div class="container">
    				<h2>Featured duplex projects</h2>
    			</div>
    			<div id="slider2" class="slider">
    				<div class="stage">
    					<div class="inside">
    						<div class="stager">
    							@foreach($all_projects as $proj)
    							    @if($proj->type_id == 3)
        							    <div class="item">
            								<div class="condo-outer">
            
            									<div class="condo-bx clearfix">
            										<a href="/project-info/{{ $proj->type_id }}/{{ $proj->id }}">
            											<img src="https://skyriseprojects.com/testapi/public/uploads/images/{{ $proj->images[0] }}" alt="" />
            											<div class="box-desc">
            												<h3>{{ $proj->name }}</h3>
        												    <h4>{{ $proj->city }}</h4>
            											</div>
            										</a>
            										<div class="box-fav"><i class="zmdi zmdi-favorite"></i></div>
            									</div>
            								</div>
            							</div>
            						@endif
    							@endforeach
    						</div>
    					</div>
    				</div>
    				<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
    				<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
    			</div>
    		</div>
    	</section>
    @endif
    
    @if($detachedCount > 0)
	    <section class="featured-condo">
    		<div class="featured-outer">
    			<div class="container">
    				<h2>Featured detached house projects</h2>
    			</div>
    			<div id="slider3" class="slider">
    				<div class="stage">
    					<div class="inside">
    						<div class="stager">
    							@foreach($all_projects as $proj)
    							    @if($proj->type_id == 2)
        							    <div class="item">
            								<div class="condo-outer">
            
            									<div class="condo-bx clearfix">
            										<a href="/project-info/{{ $proj->type_id }}/{{ $proj->id }}">
            											<img src="https://skyriseprojects.com/testapi/public/uploads/images/{{ $proj->images[0] }}" alt="" />
            											<div class="box-desc">
            												<h3>{{ $proj->name }}</h3>
        												    <h4>{{ $proj->city }}</h4>
            											</div>
            										</a>
            										<div class="box-fav"><i class="zmdi zmdi-favorite"></i></div>
            									</div>
            								</div>
            							</div>
            						@endif
    							@endforeach
    						</div>
    					</div>
    				</div>
    				<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
    				<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
    			</div>
    		</div>
    	</section>
    @endif
    
	<section class="developers-area clearfix">
		<div class="container">
			<h2>Developers</h2>
		</div>
		<div id="slider4" class="slider">
			<div class="stage">
				<div class="inside">
					<div class="stager dev-list">
						<div class="item"><a href=""><img src="../assets/images/dev-1.png" alt="" /></a></div>
						<div class="item"><a href=""><img src="../assets/images/dev-2.png" alt="" /></a></div>
						<div class="item"><a href=""><img src="../assets/images/dev-3.png" alt="" /></a></div>
						<div class="item"><a href=""><img src="../assets/images/dev-4.png" alt="" /></a></div>
						<div class="item"><a href=""><img src="../assets/images/dev-5.png" alt="" /></a></div>
						<div class="item"><a href=""><img src="../assets/images/dev-6.png" alt="" /></a></div>
						<div class="item"><a href=""><img src="../assets/images/dev-7.png" alt="" /></a></div>
						<div class="item"><a href=""><img src="../assets/images/dev-8.png" alt="" /></a></div>
					</div>
				</div>
			</div>
			<button type="button" class="webBtn prev"><i class="zmdi zmdi-chevron-left"></i></button>
			<button type="button" class="webBtn next"><i class="zmdi zmdi-chevron-right"></i></button>
		</div>
	</section>


	<div class="section footer">
		<div class="mid-align">
			<div class="container">
				<h3>CONNECT WITH US</h3>
				<ul class="social-area mob-none">
					<li>
						<div class="social-box">
							<a href="">
								<img src="assets/images/s1.png" alt="Youtube" />
								<h4>Youtube</h4>
								<span>12,455 followers</span>
							</a>
						</div>
					</li>
					<li>
						<div class="social-box">
							<a href="">
								<img src="assets/images/s2.png" alt="Facebook" />
								<h4>Instagram</h4>
								<span>8455 followers</span>
							</a>
						</div>
					</li>
					<li>
						<div class="social-box">
							<a href="">
								<img src="assets/images/s3.png" alt="Facebook" />
								<h4>Facebook</h4>
								<span>455 followers</span>
							</a>
						</div>
					</li>
					<li>
						<div class="social-box">
							<a href="">
								<img src="assets/images/s4.png" alt="Facebook" />
								<h4>Twitter</h4>
								<span>355 followers</span>
							</a>
						</div>
					</li>
					<li>
						<div class="social-box">
							<a href="">
								<img src="assets/images/s5.png" alt="Facebook" />
								<h4>LinkdIn</h4>
								<span>655 followers</span>
							</a>
						</div>
					</li>
				</ul>
				<div class="m-right-z  d-none">
					<div class="swiper-container right-z swiper-three">
						<div class="swiper-wrapper">
							<div class="swiper-slide">
								<div class="social-box">
									<a href="">
										<img src="assets/images/s1.png" alt="Youtube" />
										<h4>Youtube</h4>
										<span>12,455 followers</span>
									</a>
								</div>
							</div>
							<div class="swiper-slide">
								<div class="social-box">
									<a href="">
										<img src="assets/images/s2.png" alt="Facebook" />
										<h4>Instagram</h4>
										<span>8455 followers</span>
									</a>
								</div>
							</div>
							<div class="swiper-slide">
								<div class="social-box">
									<a href="">
										<img src="assets/images/s3.png" alt="Facebook" />
										<h4>Facebook</h4>
										<span>455 followers</span>
									</a>
								</div>
							</div>
							<div class="swiper-slide">
								<div class="social-box">
									<a href="">
										<img src="assets/images/s4.png" alt="Facebook" />
										<h4>Twitter</h4>
										<span>355 followers</span>
									</a>
								</div>
							</div>
							<div class="swiper-slide">
								<div class="social-box">
									<a href="">
										<img src="assets/images/s5.png" alt="Facebook" />
										<h4>LinkdIn</h4>
										<span>655 followers</span>
									</a>
								</div>
							</div>
						</div>
						<!-- Add Arrows -->
						<div class="swiper-button-next lrg"></div>
						<div class="swiper-button-prev lrg"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="cpr">
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<p>© 2021 Skyrise Projects, Inc. All rights reserved. </p>
					</div>
					<div class="col-sm-6">
						<div class="f-nav">
							<a href="">Legal</a> <span> | </span> <a href="">Terms of use</a> <span> |</span> <a href="">Privacy policy</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

	<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script type="text/javascript" src="assets/js/dropdown.js"></script>
	<script type="text/javascript" src="/assets/sidenav.min.js"></script>
	<script>
		$('[data-sidenav]').sidenav();
	</script>
	<script>
		var swiper = new Swiper('.swiper-two', {
			slidesPerView: 1.14,
			spaceBetween: 15,

			speed: 300,
			freeMode: false,
			slidesPerGroup: 1,
			loop: false,
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			},
			breakpoints: {

				767: {
					slidesPerView: 3,
					slidesPerGroup: 3,
					spaceBetween: 30,
					speed: 1200

				}

			}
		});
	</script>
	<script>
		var swiper = new Swiper('.swiper-three', {
			slidesPerView: 1.14,
			spaceBetween: 15,
			loop: false,
			speed: 300,
			freeMode: false,
			slidesPerGroup: 1,

			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			},
			breakpoints: {

				767: {
					slidesPerView: 3,
					slidesPerGroup: 3,
					spaceBetween: 30,
					speed: 1200,
					loop: false,

				}

			}
		});
	</script>
	<script>
		$(window).on('load', function() {

			$('body').removeClass('stop-scrolling');
		});
	</script>
	<script>
		$(window).on('load', function() {
			$('.overlay').fadeOut(500);
		})
	</script>
	<script>
		$('.panel-collapse').on('show.bs.collapse', function() {
			$(this).siblings('.panel-heading').addClass('active');
		});

		$('.panel-collapse').on('hide.bs.collapse', function() {
			$(this).siblings('.panel-heading').removeClass('active');
		});
	</script>
	<script type="text/javascript">
		var myFullpage = new fullpage('#fullpage', {
			autoScrolling: false,
			fitToSection: false,

		});
	</script>
	<script>
		$('.dropdown-el').click(function(e) {
			e.preventDefault();
			e.stopPropagation();
			$(this).toggleClass('expanded');
			$('#' + $(e.target).attr('for')).prop('checked', true);
		});
		$(document).click(function() {
			$('.dropdown-el').removeClass('expanded');
		});
	</script>
	<script>
		$(document).ready(function() {
			$(".forgot").click(function() {
				$(".login-form").hide(500);
				$(".forgot-form").show(500);
			});
		});
	</script>
	<script src="assets/js/pushy.min.js"></script>
	<script>
		$('#slct22').change(function() {
			alert('aYYZA');
			$('li.pushy-submenu').removeClass('pushy-submenu-closed');
			$('li.pushy-submenu').addClass('pushy-submenu-open');
		});
	</script>
	<script>
		$('.stat-number').each(function() {
			var size = $(this).text().split(".")[1] ? $(this).text().split(".")[1].length : 0;
			$(this).prop('Counter', 0).animate({
				Counter: $(this).text()
			}, {
				duration: 2500,
				step: function(func) {
					$(this).text(parseFloat(func).toFixed(size));
				}
			});
		});
	</script>
	<script type="text/javascript" src="assets/js/slideshow.min.js"></script>
</body>

</html>